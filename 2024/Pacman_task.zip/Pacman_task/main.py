import os
import numpy as np
import pygame
import random


'''
Переменные и константы
'''
BOARD_X = 600
BOARD_Y = 600
fps = 40
main = True
ani = 4
size = 45
addx = 1
addy = 1
f = 10

'''
Объекты
'''
class Pacman(pygame.sprite.Sprite):
    #Класс с Pacman:
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.images = []
        for i in range(1, 5):
            img = pygame.image.load(os.path.join('images', f'{i}.png')).convert_alpha()
            self.images.append(pygame.transform.scale(img, (size, size)))
            self.image = self.images[0]
            self.rect = self.image.get_rect()
        self.movex = 0
        self.movey = 0
        self.frame = 1

    def move(self, x, y):
        #перемещение спрайта:
        self.movex += x
        self.movey += y

    def update(self):
        #обновление позиции спрайта

        self.rect.x += self.movex
        self.rect.y += self.movey

        #влево:
        if self.movex < 0:
            self.frame += 1
            if self.frame > 3*ani:
                self.frame = 0
            self.image = pygame.transform.flip(self.images[self.frame//ani], True, False)
            print('self.frameLEFT=', self.frame)
        #вправо:
        if self.movex > 0:
            self.frame += 1
            if self.frame > 3*ani:
                self.frame = 0
            self.image = self.images[self.frame//ani]
            print('self.frameRIGHT=', self.frame)
        #вверх:
        if self.movey < 0:
            self.frame += 1
            if self.frame > 3*ani:
                self.frame = 0
            self.image = pygame.transform.rotate(self.images[self.frame//ani], 90)
            print('self.frameUP=', self.frame)

        #вниз:
        if self.movey > 0:
            self.frame += 1
            if self.frame > 3*ani:
                self.frame = 0
            self.image = pygame.transform.rotate(self.images[self.frame//ani], -90)
            print('self.frameDOWN=', self.frame)

class Enemy(pygame.sprite.Sprite):
    #класс с приведениями:
    def __init__(self, name):
        pygame.sprite.Sprite.__init__(self)

        self.images = []
        img = pygame.image.load(os.path.join('images', f'{name}.png')).convert_alpha()
        self.images.append(pygame.transform.scale(img, (size, size)))
        self.image = self.images[0]
        self.rect = self.image.get_rect()
        r = self.rect

        r.x = random.randrange(0, 500)
        r.y = random.randrange(0, 500)
        self.addx = addx
        self.addy = addy
        self.speedy = random.randrange(1, 4) #движение в случайном направлении
        self.speedx = random.randrange(-3, 1)
        self.timeout = timeout

    def update(self, timeout, addx, addy):
        #Перемещение спрайта приведений:

        r = self.rect
        r.x += self.speedx * self.addx
        r.y += self.speedy * self.addy


        #Ограничение игрового поля для приведений и изменение вектора скорости каждые 5 секунд

        if (r.left < 1) or (r.right > BOARD_X-2):
            self.speedx *= -1

        if timeout // 5:
            self.addx = np.sin((2*np.pi*f)/100*timeout)


        #x = A*sin(w*t), где w = 2*pi*f/fd, A - амплитуда волны - формула из радиотехники :)

        if (r.top < 1) or (r.bottom > BOARD_Y-2):
            self.speedy *= -1

        if timeout // 5:
            self.addy = np.sin((2*np.pi*f)/100*timeout)

'''
Настройка
'''
clock = pygame.time.Clock()
pygame.init()
board = pygame.display.set_mode([BOARD_X, BOARD_Y])
bg_img = pygame.image.load(os.path.join('images', '600-600.jpg'))

boardbox = board.get_rect()
pac_man = Pacman()
pac_man.rect.x = BOARD_X/2 - size/2 #Pacman появляется в центре игрового поля
pac_man.rect.y = BOARD_Y/2 - size/2
enemy_list = pygame.sprite.Group()
pac_man_list = pygame.sprite.Group()
pac_man_list.add(pac_man)
reset_time = 1

myfont = pygame.font.Font('fonts/Jersey10Charted-Regular.ttf', 100)



def add_enemys():
    names = ['blue', 'orange', 'pink', 'red']
    for i, name in enumerate(names):
        e = Enemy(name)
        enemy_list.add(e)



steps = 3



'''
Игровой цикл
'''

while main:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()

        #Управление Pacman, клавиша нажата
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                pac_man.move(-steps, 0)
            if event.key == pygame.K_RIGHT:
                pac_man.move(steps,  0)
            elif event.key == pygame.K_UP:
                pac_man.move(0,  -steps)
            elif event.key == pygame.K_DOWN:
                pac_man.move(0, steps)

        #Управление Pacman, клавиша отжата
        if event.type == pygame.KEYUP:
            if event.key == pygame.K_LEFT:
                pac_man.move(steps, 0)
            elif event.key == pygame.K_RIGHT:
                pac_man.move(-steps,  0)
            elif event.key == pygame.K_UP:
                pac_man.move(0,  steps)
            elif event.key == pygame.K_DOWN:
                pac_man.move(0, -steps)


    timeout = int((pygame.time.get_ticks() / 1000))  #прошло времени в секундах

    print(timeout)
    text_surface_time = myfont.render(str(timeout), True, 'White')
    pac_man.rect.clamp_ip(boardbox) #Pacman останавливается при столкновении со стеной

    board.blit(bg_img, boardbox)
    board.blit(text_surface_time, (15, 15))
    pac_man_list.update()
    pac_man_list.draw(board)
    enemy_list.draw(board)

    for i in enemy_list:
        t = random.uniform(0,300)
        i.update(timeout, addx, addy)

    hits = pygame.sprite.spritecollide(pac_man, enemy_list, True) #проверка столкновения
    if hits:
        print('I eat something monster')

    pygame.display.update()
    if not len(enemy_list):  #все враги съедены, добавляются новые
        add_enemys()
    clock.tick(fps)
